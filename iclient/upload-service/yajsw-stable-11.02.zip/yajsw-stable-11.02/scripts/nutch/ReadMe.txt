Sample Scripts showing how YAJSW can be used to run a workflow of applications.
This example implements web crawl for nutch/solr.
For further details refer to nutch_recrawl.gv.

Refer also to conf/samples/luceneNutch for the configuration files for wrapping these scripts.