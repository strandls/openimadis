/**
 * Provides hessian rpc server side handling
 * <br>
 * {@link HessianRPCServiceHandler}  is the netty handler which handles
 * server side hessian RPC requests.
 */
package org.rzo.netty.ahessian.rpc.server;