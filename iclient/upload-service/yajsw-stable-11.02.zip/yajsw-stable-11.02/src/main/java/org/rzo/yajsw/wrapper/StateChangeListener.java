package org.rzo.yajsw.wrapper;

public interface StateChangeListener
{
	public void stateChange(int newState, int oldState);
}
