package org.rzo.yajsw.wrapper;

public interface TriggerListener
{

}
