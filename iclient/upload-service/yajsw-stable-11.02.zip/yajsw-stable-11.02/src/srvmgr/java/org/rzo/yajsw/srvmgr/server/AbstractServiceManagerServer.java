package org.rzo.yajsw.srvmgr.server;

public abstract class AbstractServiceManagerServer implements ServiceManagerServer
{
	public void addClientServer(String server)
	{
		
	}
	public void removeClientServer(String server)
	{
		
	}


}
